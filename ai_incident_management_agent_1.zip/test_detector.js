// /home/ubuntu/test_detector.js
const { detectIncidents } = require("./src/modules/incidentDetector/index");
const dotenv = require("dotenv");

// Load environment variables from .env file in the project root /home/ubuntu/
dotenv.config({ path: "/home/ubuntu/.env" }); 

async function runFullCycleWithAI_RCA() {
    console.log("--- Starting Full Anomaly Detection, AI RCA, Jira Ticketing, & Slack Notification Test Cycle ---");

    const testAppName = process.env.TEST_NEW_RELIC_APP_NAME;
    const requiredEnvVars = [
        "NEW_RELIC_API_KEY",
        "NEW_RELIC_ACCOUNT_ID",
        "TEST_NEW_RELIC_APP_NAME",
        "JIRA_BASE_URL",
        "JIRA_EMAIL",
        "JIRA_PAT",
        "JIRA_DEFAULT_PROJECT_KEY",
        "SLACK_BOT_TOKEN",
        "DEFAULT_SLACK_CHANNEL_ID",
        "DEEPSEEK_API_KEY" // Added for AI RCA
    ];

    let missingVars = false;
    for (const varName of requiredEnvVars) {
        if (!process.env[varName]) {
            console.error(`Error: Environment variable ${varName} is not set. Please set it in /home/ubuntu/.env`);
            missingVars = true;
        }
    }

    if (missingVars) {
        console.error("Aborting test due to missing environment variables.");
        return;
    }

    console.log(`\nTesting with New Relic application: ${testAppName}`);
    console.log(`Will attempt to generate AI RCA suggestions using DeepSeek.`);
    console.log(`Will attempt to create Jira tickets in project: ${process.env.JIRA_DEFAULT_PROJECT_KEY} at ${process.env.JIRA_BASE_URL}`);
    console.log(`Will attempt to send Slack notifications to channel ID: ${process.env.DEFAULT_SLACK_CHANNEL_ID}`);
    
    try {
        console.log("\nStep 1: Detecting incidents (fetching New Relic data, generating AI RCA, creating Jira ticket, sending Slack notification)...");
        const anomalies = await detectIncidents(testAppName);

        if (anomalies && anomalies.length > 0) {
            console.log("\nStep 2: Incident detection reported anomalies. AI RCA, Jira ticket creation, and Slack notification should have been attempted by detectIncidents.");
            console.log("Please check your Jira instance for a new ticket (description should include AI RCA suggestions) and your Slack channel for a notification related to:", anomalies[0].service);
        } else {
            console.log("\nStep 2: No anomalies were detected by detectIncidents. No AI RCA, Jira ticket, or Slack notification would be actioned.");
        }

    } catch (error) {
        console.error(`Failed to run the full incident detection, AI RCA, ticketing, and notification cycle for ${testAppName}:`, error.message);
    }
    
    console.log("\n--- Full Anomaly Detection, AI RCA, Jira Ticketing, & Slack Notification Test Cycle Complete ---");
    console.log("Reminder: Check console logs above for details on metrics fetched, anomalies detected, AI RCA attempts, Jira ticket creation attempts, and Slack notification attempts.");
}

// Run the test
runFullCycleWithAI_RCA().catch(error => {
    console.error("Test cycle failed unexpectedly:", error);
});

