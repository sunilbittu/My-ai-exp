## AI-Powered Incident Management Agent - Node.js Prototype

This project is a Node.js prototype for an AI-powered incident management agent. The goal is to leverage New Relic data, integrate with services like Jira and Slack, and use AI (potentially via models like DeepSeek's) to automate and enhance incident detection, RCA, and management.

### Current Implemented Components (as of this stage):

1.  **Project Structure:** A modular Node.js project structure has been defined (see `project_structure.md` for details).
2.  **GPT Service (`src/services/gptService.js`):**
    *   Handles communication with the DeepSeek API (or a similar GPT model API).
    *   Provides a `generateText` function to get completions from the model.
    *   Requires `DEEPSEEK_API_KEY` environment variable.
3.  **Anomaly Detection Prototype (`src/modules/incidentDetector/`):**
    *   `anomalyDetection.js`: Contains logic to simulate fetching metrics (as `newrelicService.js` is not yet built) and apply basic threshold-based anomaly detection rules for different services.
    *   `index.js`: The main module for incident detection. It uses `anomalyDetection.js` to find anomalies and logs them. It includes commented-out placeholders for future integration with the GPT service for insights and with ticket/communication managers.
4.  **Test Script (`test_detector.js`):**
    *   A simple script to run the `detectIncidents` function for a few sample services and observe the output of the anomaly detection prototype.

### Setup and Running the Current Prototype:

1.  **Prerequisites:**
    *   Node.js (e.g., v18.x or higher recommended)
    *   npm (comes with Node.js)

2.  **Installation & Setup:**
    *   Ensure you have the following files in your project directory (`/home/ubuntu/` based on our work):
        *   `src/services/gptService.js`
        *   `src/modules/incidentDetector/anomalyDetection.js`
        *   `src/modules/incidentDetector/index.js`
        *   `test_detector.js`
        *   `package.json` (you'll need to create this, see below)
        *   `.env` file (for API keys)

    *   **Create `package.json`:**
        If you don't have one, run `npm init -y` in your project root (`/home/ubuntu/`).
        Then, install `axios` (used by `gptService.js`) and `dotenv` (to manage environment variables):
        ```bash
        npm install axios dotenv
        ```

    *   **Create `.env` file:**
        In your project root (`/home/ubuntu/`), create a file named `.env` and add your DeepSeek API key:
        ```
        DEEPSEEK_API_KEY=your_actual_deepseek_api_key_here
        ```

3.  **Running the Test Script:**
    From your project root (`/home/ubuntu/`), run:
    ```bash
    node test_detector.js
    ```
    You should see output indicating the services being tested and any anomalies detected by the prototype logic.

### Next Steps for Further Development:

1.  **Implement `newrelicService.js`:**
    *   Connect to the New Relic API (using their Node.js SDK or direct API calls).
    *   Implement functions to fetch actual metrics, alerts, and other relevant data needed by the `incidentDetector`.
    *   Replace the `getSimulatedMetrics` function in `anomalyDetection.js` with calls to this new service.

2.  **Implement `jiraService.js`:**
    *   Integrate with the Jira API (e.g., using a library like `jira-client` or `axios`).
    *   Implement functions to create Jira tickets with details from detected incidents.
    *   Handle authentication securely (API tokens).

3.  **Implement `slackService.js`:**
    *   Integrate with the Slack API (e.g., using `@slack/web-api`).
    *   Implement functions to: 
        *   Send notifications to specific channels or users.
        *   Create dedicated incident channels.
        *   Post incident details and Jira ticket links.

4.  **Develop `ticketManager.js` and `communicationManager.js`:**
    *   These modules in `src/modules/` will orchestrate the use of `jiraService.js` and `slackService.js` respectively, based on detected incidents from `incidentDetector`.

5.  **Enhance Anomaly Detection (`anomalyDetection.js`):**
    *   Move beyond basic thresholds.
    *   Implement more sophisticated statistical methods (e.g., dynamic baselining, standard deviation analysis).
    *   Explore machine learning models for time-series anomaly detection if feasible for the hackathon.

6.  **Integrate GPT Service (`gptService.js`) More Deeply:**
    *   Use `gptService.js` in `incidentDetector/index.js` to generate human-readable descriptions of anomalies.
    *   Develop `rcaAssistant.js` to use GPT for suggesting potential root causes based on aggregated data.
    *   Develop `summaryGenerator.js` to use GPT to create incident summaries post-resolution.

7.  **Build `app.js` (Main Application Logic/Server):**
    *   If the agent needs to run continuously or respond to webhooks (e.g., New Relic alert notifications), set up an Express.js server.
    *   Define routes for webhook endpoints or manual triggers.
    *   Implement a main loop or scheduler to periodically run `detectIncidents` for configured services.

8.  **Configuration Management (`src/config/`):**
    *   Implement a robust configuration system (e.g., using the `config` npm package) to manage New Relic API keys, Jira/Slack credentials, service names to monitor, anomaly thresholds, etc.

9.  **Error Handling and Logging (`src/utils/`):**
    *   Implement centralized error handling.
    *   Add comprehensive logging using a library like `winston` or `pino`.

10. **Testing:**
    *   Write unit tests for each service and module.
    *   Develop integration tests for key workflows (e.g., anomaly detected -> Jira ticket created -> Slack notification sent).

This README provides a snapshot of the current progress and a roadmap for building out the full AI-Powered Incident Management Agent. Good luck with your hackathon!




## Update: New Relic Integration for Real-time Metrics

The incident detection prototype has been updated to integrate with New Relic, allowing it to fetch and analyze real-time application metrics instead of using simulated data.

### Components Involved:

1.  **`src/services/newrelicService.js`:**
    *   This new service is responsible for all communication with the New Relic NerdGraph API.
    *   It exports an `executeNRQL(nrqlQuery, apiKey)` function that takes an NRQL query string and an optional API key (defaults to `process.env.NEW_RELIC_API_KEY`).
    *   It requires the `NEW_RELIC_API_KEY` and `NEW_RELIC_ACCOUNT_ID` to be set in your `/home/ubuntu/.env` file.
    *   It uses `node-fetch` for making API calls.

2.  **`src/modules/incidentDetector/anomalyDetection.js` (Updated):**
    *   The `getSimulatedMetrics(appName)` function has been replaced with `getNewRelicMetrics(appName)`.
    *   `getNewRelicMetrics(appName)` now uses `newrelicService.executeNRQL` to fetch `average(duration) * 1000 AS responseTimeMs` and `percentage(count(*), WHERE error IS TRUE) AS errorRatePercent` for the specified `appName` from New Relic for the last 5 minutes.
    *   The `checkForAnomalies(serviceName, metrics)` function remains largely the same but now operates on real data. The `serviceName` parameter should correspond to an `appName` you monitor in New Relic and have thresholds defined for.

3.  **`src/modules/incidentDetector/index.js` (Updated):**
    *   The `detectIncidents(appName)` function now calls `getNewRelicMetrics(appName)` instead of the simulated version.
    *   The `appName` parameter passed to `detectIncidents` should be the actual application name as configured in your New Relic account.

4.  **`test_detector.js` (Updated):**
    *   This script now specifically tests the New Relic integration.
    *   It requires you to set `NEW_RELIC_API_KEY`, `NEW_RELIC_ACCOUNT_ID`, and `TEST_NEW_RELIC_APP_NAME` in your `/home/ubuntu/.env` file.
    *   It calls `detectIncidents` with the `TEST_NEW_RELIC_APP_NAME`.

### Setup and Running with New Relic Integration:

1.  **Prerequisites:**
    *   Ensure `node-fetch` is installed: `npm install node-fetch` (if not already).
    *   Ensure `dotenv` is installed: `npm install dotenv` (if not already).

2.  **Update `.env` file:**
    In your `/home/ubuntu/.env` file, make sure you have the following (replace with your actual values):
    ```
    DEEPSEEK_API_KEY=your_actual_deepseek_api_key_here
    NEW_RELIC_API_KEY=your_new_relic_user_api_key
    NEW_RELIC_ACCOUNT_ID=your_new_relic_account_id
    TEST_NEW_RELIC_APP_NAME=YourApplicationNameInNewRelic
    ```

3.  **Running the Test Script:**
    From your project root (`/home/ubuntu/`), run:
    ```bash
    node test_detector.js
    ```
    The script will now attempt to fetch live data from your New Relic application and report any anomalies based on the thresholds defined in `anomalyDetection.js`.

### Next Steps (Reiteration and Refinement):

With real data flowing from New Relic, the next logical steps are:

1.  **Implement `jiraService.js`:** Integrate with the Jira API to create tickets when anomalies are detected by `incidentDetector`.
2.  **Implement `slackService.js`:** Integrate with the Slack API to send notifications.
3.  **Develop `ticketManager.js` and `communicationManager.js`:** Orchestrate the use of Jira and Slack services.
4.  **Refine Anomaly Detection Logic & Thresholds:**
    *   Make thresholds in `anomalyDetection.js` more configurable (e.g., load from a config file or per-service settings).
    *   Implement more sophisticated NRQL queries in `getNewRelicMetrics` to fetch a richer set of data or allow for more dynamic query generation.
    *   Explore more advanced anomaly detection techniques beyond simple thresholds.
5.  **Integrate `gptService.js`:**
    *   Uncomment and complete the GPT integration in `incidentDetector/index.js` to generate human-readable descriptions of anomalies.
    *   Develop `rcaAssistant.js` and `summaryGenerator.js`.
6.  **Build `app.js` (Main Application Logic/Server):** For continuous monitoring or webhook handling.
7.  **Robust Configuration, Error Handling, and Logging.**
8.  **Comprehensive Unit and Integration Testing.**




## Update: Jira Integration for Automated Incident Ticketing

The incident management agent has now been enhanced with Jira integration, enabling it to automatically create Jira tickets when anomalies are detected from New Relic data.

### Components Involved:

1.  **`src/services/jiraService.js`:**
    *   This service handles all direct communication with the Jira Cloud REST API (v3).
    *   It exports a `createJiraTicket(ticketDetails)` function.
    *   Authentication is done using Basic Auth with your Jira email and a Personal Access Token (PAT).
    *   Requires `JIRA_BASE_URL`, `JIRA_EMAIL`, and `JIRA_PAT` to be set in your `/home/ubuntu/.env` file.
    *   Uses `node-fetch` for API calls.

2.  **`src/modules/ticketManager/index.js`:**
    *   This module orchestrates the ticket creation logic.
    *   It exports `createIncidentTicketFromAnomalies(anomalies, config = {})` which takes the detected anomalies and formats them into a structured Jira ticket.
    *   It uses `jiraService.js` to create the actual ticket.
    *   It uses environment variables for default Jira project key (`JIRA_DEFAULT_PROJECT_KEY`), issue type (`JIRA_DEFAULT_INCIDENT_ISSUE_TYPE`), and priority (`JIRA_DEFAULT_INCIDENT_PRIORITY`), which can be set in `/home/ubuntu/.env`.

3.  **`src/modules/incidentDetector/index.js` (Updated):**
    *   The `detectIncidents(appName)` function now imports and calls `createIncidentTicketFromAnomalies` from the `ticketManager` if anomalies are detected.
    *   This links the anomaly detection directly to automated ticket creation.

4.  **`test_detector.js` (Updated):**
    *   This script now tests the full end-to-end flow: fetching data from New Relic, detecting anomalies, and attempting to create a Jira ticket.
    *   It requires all necessary New Relic and Jira environment variables to be set in `/home/ubuntu/.env` for a successful test run.

### Setup and Running with Jira Integration:

1.  **Prerequisites:**
    *   Ensure `node-fetch` and `dotenv` are installed (`npm install node-fetch dotenv`).

2.  **Update `.env` file:**
    In your `/home/ubuntu/.env` file, ensure you have the following (replace with your actual values):
    ```
    DEEPSEEK_API_KEY=your_actual_deepseek_api_key_here
    NEW_RELIC_API_KEY=your_new_relic_user_api_key
    NEW_RELIC_ACCOUNT_ID=your_new_relic_account_id
    TEST_NEW_RELIC_APP_NAME=YourApplicationNameInNewRelic
    JIRA_BASE_URL=https://your-domain.atlassian.net
    JIRA_EMAIL=your_jira_login_email@example.com
    JIRA_PAT=your_jira_personal_access_token
    JIRA_DEFAULT_PROJECT_KEY=YOUR_JIRA_PROJECT_KEY
    JIRA_DEFAULT_INCIDENT_ISSUE_TYPE=Bug # Or Incident, Task, etc.
    JIRA_DEFAULT_INCIDENT_PRIORITY=High # Or Medium, Low, etc.
    ```

3.  **Running the Test Script:**
    From your project root (`/home/ubuntu/`), run:
    ```bash
    node test_detector.js
    ```
    The script will attempt to fetch live data from your New Relic application, detect anomalies, and if any are found, create a ticket in your specified Jira project. Check the console output and your Jira instance for results.

### Next Steps (Reiteration and Refinement):

With New Relic and Jira integrations in place, the next logical steps are:

1.  **Implement `slackService.js`:** Integrate with the Slack API to send notifications about new incidents and created Jira tickets.
2.  **Develop `communicationManager.js`:** Orchestrate the use of the Slack service to notify relevant teams/channels.
3.  **Integrate `communicationManager.js` into `incidentDetector/index.js`:** After a ticket is created (or an attempt is made), notify via Slack.
4.  **Refine Anomaly Detection Logic & Thresholds:** Continue to improve the accuracy and configurability of anomaly detection.
5.  **Integrate `gptService.js` More Deeply:** For RCA assistance and incident summarization.
6.  **Build `app.js` (Main Application Logic/Server):** For continuous monitoring or webhook handling.
7.  **Robust Configuration, Error Handling, and Logging.**
8.  **Comprehensive Unit and Integration Testing for all components.**




## Update: Slack Integration for Automated Incident Notifications

The AI-Powered Incident Management Agent now includes Slack integration, enabling it to send real-time notifications to a designated Slack channel when incidents are detected and Jira tickets are created.

### Components Involved:

1.  **`src/services/slackService.js`:**
    *   This service handles all direct communication with the Slack Web API.
    *   It uses the `@slack/web-api` official library.
    *   It exports a `sendMessageToChannel(channelId, text, blocks)` function.
    *   Authentication is done using a Slack Bot Token.
    *   Requires `SLACK_BOT_TOKEN` to be set in your `/home/ubuntu/.env` file.

2.  **`src/modules/communicationManager/index.js`:**
    *   This module orchestrates the notification logic.
    *   It exports `notifyIncidentOnSlack(anomalies, jiraTicketResult)` which takes detected anomalies and the Jira ticket creation result.
    *   It formats a rich message using Slack Block Kit, including incident details and a link to the Jira ticket.
    *   It uses `slackService.js` to send the message.
    *   It requires `DEFAULT_SLACK_CHANNEL_ID` (the ID of your target Slack channel) to be set in `/home/ubuntu/.env`.

3.  **`src/modules/incidentDetector/index.js` (Updated):**
    *   The `detectIncidents(appName)` function now imports and calls `notifyIncidentOnSlack` from the `communicationManager` after anomalies are detected and a Jira ticket creation attempt has been made.
    *   This completes the automated flow: New Relic Anomaly -> Jira Ticket -> Slack Notification.

4.  **`test_detector.js` (Updated):**
    *   This script now tests the full end-to-end flow: fetching data from New Relic, detecting anomalies, attempting to create a Jira ticket, and attempting to send a Slack notification.
    *   It requires all necessary New Relic, Jira, and Slack environment variables to be set in `/home/ubuntu/.env` for a successful test run.

### Setup and Running with Slack Integration:

1.  **Prerequisites:**
    *   Ensure `node-fetch`, `dotenv`, and `@slack/web-api` are installed (`npm install node-fetch dotenv @slack/web-api`).

2.  **Update `.env` file:**
    In your `/home/ubuntu/.env` file, ensure you have the following (replace with your actual values):
    ```
    DEEPSEEK_API_KEY=your_actual_deepseek_api_key_here
    NEW_RELIC_API_KEY=your_new_relic_user_api_key
    NEW_RELIC_ACCOUNT_ID=your_new_relic_account_id
    TEST_NEW_RELIC_APP_NAME=YourApplicationNameInNewRelic
    JIRA_BASE_URL=https://your-domain.atlassian.net
    JIRA_EMAIL=your_jira_login_email@example.com
    JIRA_PAT=your_jira_personal_access_token
    JIRA_DEFAULT_PROJECT_KEY=YOUR_JIRA_PROJECT_KEY
    JIRA_DEFAULT_INCIDENT_ISSUE_TYPE=Bug # Or Incident, Task, etc.
    JIRA_DEFAULT_INCIDENT_PRIORITY=High # Or Medium, Low, etc.
    SLACK_BOT_TOKEN=xoxb-your-slack-bot-token
    DEFAULT_SLACK_CHANNEL_ID=C0123ABCXYZ # Your target Slack channel ID
    ```

3.  **Running the Test Script:**
    From your project root (`/home/ubuntu/`), run:
    ```bash
    node test_detector.js
    ```
    The script will attempt the full flow. Check your console output, your Jira instance, and your designated Slack channel for results.

### Next Steps (Consolidated and Future Enhancements):

With New Relic, Jira, and Slack integrations forming a core automated incident response pipeline, here are the next logical steps for evolving this agent:

1.  **Deepen AI Integration (`gptService.js`):**
    *   **RCA Assistance:** Use the `gptService.js` (with your DeepSeek API key) to analyze anomaly data and suggest potential root causes or investigation steps. This could be added to the Jira ticket description or Slack message.
    *   **Incident Summarization:** After an incident is resolved (manual step for now), use GPT to generate a concise summary based on the anomalies, Jira ticket details, and potentially any resolution notes (if a mechanism to input them is added).
    *   Implement `src/modules/rcaAssistant/index.js` and `src/modules/summaryGenerator/index.js`.

2.  **Build `app.js` (Main Application Logic/Server):**
    *   Transform the `test_detector.js` logic into a continuously running application (e.g., using `setInterval` for polling, or by exposing a webhook that New Relic alerts could trigger).
    *   This `app.js` would be the main entry point for the agent in a deployed state.

3.  **Configuration Management:**
    *   Move thresholds from `anomalyDetection.js` into a more dynamic configuration system (e.g., a JSON config file, or even fetched from a configuration service or New Relic itself).
    *   Allow per-service/app configurations for thresholds, Jira projects, Slack channels, etc.

4.  **Advanced Slack Interactions:**
    *   Allow creation of dedicated incident channels in Slack.
    *   Implement interactive components (buttons, modals) in Slack messages for actions like acknowledging an incident, assigning it, or marking it as resolved.

5.  **Error Handling and Resilience:**
    *   Implement more robust error handling, retries for API calls, and dead-letter queues for failed notifications/ticketing.
    *   Add comprehensive logging to a file or a logging service.

6.  **Comprehensive Testing:**
    *   Write unit tests for each module and service.
    *   Develop more extensive integration tests.

7.  **Security Enhancements:**
    *   Consider using a secrets management solution for API keys instead of just `.env` files for a production deployment.

This provides a solid roadmap for turning the current prototype into a more feature-rich and robust AI-Powered Incident Management Agent for your hackathon!



## Update: AI-Powered Root Cause Analysis (RCA) Suggestions

The AI-Powered Incident Management Agent has been significantly enhanced with an AI-driven Root Cause Analysis (RCA) assistant. This feature leverages the DeepSeek API (via `gptService.js`) to provide potential root causes and troubleshooting steps when an incident is detected, and these suggestions are automatically included in the Jira ticket.

### Components Involved:

1.  **`src/services/gptService.js` (Existing but now actively used for RCA):**
    *   Handles communication with the DeepSeek API (or any configured GPT-compatible model).
    *   Requires `DEEPSEEK_API_KEY` to be set in your `/home/ubuntu/.env` file.

2.  **`src/modules/rcaAssistant/index.js` (New):**
    *   This new module is responsible for generating AI-powered RCA suggestions.
    *   It exports a `getAI_RCASuggestions(anomalies)` function that takes the detected anomalies as input.
    *   It constructs a detailed prompt for the AI, asking for potential common root causes and initial troubleshooting steps based on the anomaly data.
    *   It uses `gptService.generateText` to get the suggestions from the AI model.
    *   Returns a formatted string containing the AI suggestions, or null if an error occurs.

3.  **`src/modules/ticketManager/index.js` (Updated):**
    *   The `createIncidentTicketFromAnomalies(anomalies, aiRcaSuggestions = null, config = {})` function now accepts an optional `aiRcaSuggestions` string.
    *   If provided, these AI-generated suggestions are appended to the Jira ticket description.
    *   A label "ai-assisted-rca" is also added to the Jira ticket.

4.  **`src/modules/incidentDetector/index.js` (Updated):**
    *   After anomalies are detected, `detectIncidents(appName)` now calls `getAI_RCASuggestions` from the `rcaAssistant` module.
    *   The returned AI suggestions are then passed to `createIncidentTicketFromAnomalies` when creating the Jira ticket.
    *   Error handling is in place to ensure the incident flow continues even if AI suggestion generation fails.

5.  **`test_detector.js` (Updated):**
    *   This script now tests the full end-to-end flow, including AI-powered RCA suggestion generation.
    *   It requires the `DEEPSEEK_API_KEY` in addition to all New Relic, Jira, and Slack environment variables to be set in `/home/ubuntu/.env` for a successful test run.

### Setup and Running with AI-Powered RCA:

1.  **Prerequisites:**
    *   Ensure `node-fetch`, `dotenv`, and `@slack/web-api` are installed.
    *   Ensure your `gptService.js` is correctly configured (it uses `axios` by default, so `npm install axios` if you haven't already for that service).

2.  **Update `.env` file:**
    In your `/home/ubuntu/.env` file, ensure you have all the previously mentioned variables plus the DeepSeek API key:
    ```
    DEEPSEEK_API_KEY=your_actual_deepseek_api_key_here
    NEW_RELIC_API_KEY=your_new_relic_user_api_key
    NEW_RELIC_ACCOUNT_ID=your_new_relic_account_id
    TEST_NEW_RELIC_APP_NAME=YourApplicationNameInNewRelic
    JIRA_BASE_URL=https://your-domain.atlassian.net
    JIRA_EMAIL=your_jira_login_email@example.com
    JIRA_PAT=your_jira_personal_access_token
    JIRA_DEFAULT_PROJECT_KEY=YOUR_JIRA_PROJECT_KEY
    JIRA_DEFAULT_INCIDENT_ISSUE_TYPE=Bug # Or Incident, Task, etc.
    JIRA_DEFAULT_INCIDENT_PRIORITY=High # Or Medium, Low, etc.
    SLACK_BOT_TOKEN=xoxb-your-slack-bot-token
    DEFAULT_SLACK_CHANNEL_ID=C0123ABCXYZ # Your target Slack channel ID
    ```

3.  **Running the Test Script:**
    From your project root (`/home/ubuntu/`), run:
    ```bash
    node test_detector.js
    ```
    The script will attempt the full flow. Check your console output for logs related to AI RCA suggestion generation, your Jira instance (the ticket description should now include AI suggestions), and your Slack channel.

### Next Steps (Consolidated and Future Enhancements):

With the core pipeline (New Relic -> AI RCA -> Jira -> Slack) now prototyped, the agent is significantly more intelligent. Future enhancements can focus on:

1.  **AI-Powered Incident Summarization:**
    *   After an incident is (manually for now) marked as resolved, use `gptService.js` to generate a concise summary based on anomalies, Jira ticket details (including AI RCA), and any resolution notes (if a mechanism to input them is added).
    *   Implement `src/modules/summaryGenerator/index.js`.

2.  **Build `app.js` (Main Application Logic/Server):**
    *   Transform the `test_detector.js` logic into a continuously running application (e.g., using `setInterval` for polling New Relic, or by exposing a webhook that New Relic alerts could trigger).
    *   This `app.js` would be the main entry point for the agent in a deployed state.

3.  **Refine AI Prompts and RCA Logic:**
    *   Iteratively improve the prompts sent to the DeepSeek API for more accurate and context-aware RCA suggestions.
    *   Consider allowing `rcaAssistant` to fetch additional context from New Relic (e.g., recent deployments, related service metrics, log snippets) to provide to the AI for even better RCA.

4.  **Configuration Management:**
    *   Move thresholds, AI prompts, Jira project mappings, and Slack channel configurations into a more dynamic system (e.g., JSON config files, database, or a dedicated configuration service).

5.  **Advanced Slack Interactions:**
    *   Allow creation of dedicated incident channels in Slack.
    *   Implement interactive components (buttons, modals) in Slack messages for actions like acknowledging an incident, assigning it, adding notes, or marking it as resolved.

6.  **Error Handling, Resilience, and Logging:**
    *   Implement more robust error handling across all services and modules, including retries for API calls and dead-letter queues for failed operations.
    *   Add comprehensive structured logging to a file or a logging service (e.g., New Relic Logs).

7.  **Comprehensive Testing:**
    *   Write unit tests for each module (`rcaAssistant`, `summaryGenerator`, etc.) and service.
    *   Develop more extensive integration tests for the end-to-end flows.

8.  **Security Enhancements:**
    *   For production, use a secure secrets management solution for all API keys and sensitive credentials.

This AI-RCA enhancement marks a major milestone for your hackathon project!
