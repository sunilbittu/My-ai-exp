// src/modules/ticketManager/index.js
const { createJiraTicket } = require("../../services/jiraService");

// Default configuration for ticket creation - can be overridden or made more dynamic
const DEFAULT_JIRA_PROJECT_KEY = process.env.JIRA_DEFAULT_PROJECT_KEY || "PROJ"; // Set in .env
const DEFAULT_ISSUE_TYPE_NAME = process.env.JIRA_DEFAULT_INCIDENT_ISSUE_TYPE || "Bug"; // e.g., "Incident", "Bug"
const DEFAULT_PRIORITY_NAME = process.env.JIRA_DEFAULT_INCIDENT_PRIORITY || "High";

/**
 * Creates a Jira incident ticket based on detected anomalies and optional AI RCA suggestions.
 * @param {Array<object>} anomalies - An array of anomaly objects from the incidentDetector.
 * @param {string|null} [aiRcaSuggestions] - (Optional) AI-generated RCA suggestions string.
 * @param {object} [config] - Optional configuration to override defaults.
 * @param {string} [config.projectKey] - Jira project key.
 * @param {string} [config.issueTypeName] - Jira issue type name for incidents.
 * @param {string} [config.priorityName] - Jira priority name.
 * @param {Array<string>} [config.labels] - Additional labels for the ticket.
 * @returns {Promise<object|null>} The Jira API response if successful, or null if no anomalies or error.
 */
async function createIncidentTicketFromAnomalies(anomalies, aiRcaSuggestions = null, config = {}) {
    if (!anomalies || anomalies.length === 0) {
        console.log("TicketManager: No anomalies provided, no ticket will be created.");
        return null;
    }

    const firstAnomaly = anomalies[0];
    const summary = `Automated Incident: ${firstAnomaly.type} on ${firstAnomaly.service}`;

    let descriptionContent = `The following anomalies were detected for service ${firstAnomaly.service}:\n\n`;
    anomalies.forEach(anomaly => {
        descriptionContent += `- Type: ${anomaly.type}\n`;
        descriptionContent += `  Metric: ${anomaly.metric}\n`;
        descriptionContent += `  Value: ${anomaly.value}\n`;
        descriptionContent += `  Threshold: ${anomaly.threshold}\n`;
        descriptionContent += `  Message: ${anomaly.message}\n\n`;
    });

    if (aiRcaSuggestions) {
        descriptionContent += `${aiRcaSuggestions}`; // Append AI suggestions
    }

    // Add link to New Relic or other monitoring if available (future enhancement)
    // descriptionContent += "\nFor more details, check New Relic: [Link to dashboard for service]";

    const ticketDetails = {
        projectKey: config.projectKey || DEFAULT_JIRA_PROJECT_KEY,
        summary: summary,
        description: descriptionContent, // Pass the combined string directly
        issueTypeName: config.issueTypeName || DEFAULT_ISSUE_TYPE_NAME,
        priorityName: config.priorityName || DEFAULT_PRIORITY_NAME,
        labels: ["auto-generated", "incident", "ai-assisted-rca", firstAnomaly.service, firstAnomaly.type, ...(config.labels || [])],
    };

    try {
        console.log(`TicketManager: Attempting to create Jira ticket for ${firstAnomaly.service}...`);
        // Note: jiraService.createJiraTicket expects description as a simple string for basic paragraph ADF.
        // If more complex ADF is needed for AI suggestions (e.g., formatting), jiraService would need enhancement.
        const jiraResponse = await createJiraTicket(ticketDetails);
        console.log(`TicketManager: Jira ticket ${jiraResponse.key} created successfully.`);
        return jiraResponse;
    } catch (error) {
        console.error(`TicketManager: Failed to create Jira ticket for ${firstAnomaly.service}. Error: ${error.message}`);
        return null;
    }
}

module.exports = {
    createIncidentTicketFromAnomalies,
};

// Example of how to use it (for testing purposes - requires .env setup for Jira):
// (async () => {
//     if (require.main === module) { // Only run if this script is executed directly
//         require("dotenv").config({ path: "../../.env" }); // Adjust path to .env

//         const sampleAnomalies = [
//             {
//                 type: "HighResponseTime",
//                 service: "WebApp-Prod",
//                 metric: "responseTimeMs",
//                 value: 550,
//                 threshold: 450,
//                 message: "High response time detected for WebApp-Prod: 550.00ms (Threshold: 450ms)",
//             }
//         ];
//         const sampleAISuggestions = "\n\n--- AI-Powered RCA Suggestions ---\n1. Potential Cause: Recent deployment introduced inefficient code.\n   Troubleshooting: Review recent deployment changes and performance profiles.\n2. Potential Cause: Increased load on downstream service.\n   Troubleshooting: Check metrics for dependent services.";

//         if (!process.env.JIRA_BASE_URL || !process.env.JIRA_DEFAULT_PROJECT_KEY) {
//             console.warn("Please ensure JIRA_BASE_URL, JIRA_EMAIL, JIRA_PAT, and JIRA_DEFAULT_PROJECT_KEY are set in .env for testing ticketManager.");
//             return;
//         }

//         await createIncidentTicketFromAnomalies(sampleAnomalies, sampleAISuggestions);
//     }
// })();

