// src/modules/communicationManager/index.js
const { sendMessageToChannel } = require("../../services/slackService");

// Environment variable for the default Slack channel ID to send notifications
// Set in .env, e.g., DEFAULT_SLACK_CHANNEL_ID=C0123456789
const DEFAULT_SLACK_CHANNEL_ID = process.env.DEFAULT_SLACK_CHANNEL_ID;

/**
 * Formats and sends an incident notification to a pre-configured Slack channel.
 * @param {Array<object>} anomalies - An array of anomaly objects from the incidentDetector.
 * @param {object|null} jiraTicketResult - The result from Jira ticket creation (contains key, self link), or null.
 * @returns {Promise<object|null>} The Slack API response if successful, or null if channel ID not set or error.
 */
async function notifyIncidentOnSlack(anomalies, jiraTicketResult) {
    if (!DEFAULT_SLACK_CHANNEL_ID) {
        console.warn("CommunicationManager: DEFAULT_SLACK_CHANNEL_ID is not set. Cannot send Slack notification.");
        return null;
    }

    if (!anomalies || anomalies.length === 0) {
        console.log("CommunicationManager: No anomalies provided, no Slack notification will be sent.");
        return null;
    }

    const firstAnomaly = anomalies[0];
    const serviceName = firstAnomaly.service;
    let jiraLinkText = "Jira ticket not created or creation failed.";
    if (jiraTicketResult && jiraTicketResult.key) {
        const jiraTicketUrl = `${process.env.JIRA_BASE_URL}/browse/${jiraTicketResult.key}`;
        jiraLinkText = `<${jiraTicketUrl}|${jiraTicketResult.key}>`;
    }

    // Constructing a Block Kit message for Slack
    const blocks = [
        {
            "type": "header",
            "text": {
                "type": "plain_text",
                "text": ":alert: Automated Incident Detected: " + serviceName,
                "emoji": true
            }
        },
        {
            "type": "section",
            "fields": [
                {
                    "type": "mrkdwn",
                    "text": `*Service:*\n${serviceName}`
                },
                {
                    "type": "mrkdwn",
                    "text": `*Jira Ticket:*\n${jiraLinkText}`
                }
            ]
        },
        {
            "type": "divider"
        },
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": "*Detected Anomalies:*"
            }
        }
    ];

    anomalies.forEach(anomaly => {
        blocks.push({
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": `	- *Type:* ${anomaly.type}\n	- *Metric:* ${anomaly.metric}\n	- *Value:* ${anomaly.value} (Threshold: ${anomaly.threshold})\n	- *Message:* ${anomaly.message}`
            }
        });
    });

    const fallbackText = `Incident Detected for ${serviceName}. Anomalies: ${anomalies.map(a => a.message).join("; ")}. Jira: ${jiraTicketResult ? jiraTicketResult.key : "N/A"}`;

    try {
        console.log(`CommunicationManager: Attempting to send Slack notification for ${serviceName} to channel ${DEFAULT_SLACK_CHANNEL_ID}...`);
        const slackResponse = await sendMessageToChannel(DEFAULT_SLACK_CHANNEL_ID, fallbackText, blocks);
        if (slackResponse) {
            console.log(`CommunicationManager: Slack notification sent successfully for ${serviceName}.`);
        }
        return slackResponse;
    } catch (error) {
        console.error(`CommunicationManager: Failed to send Slack notification for ${serviceName}. Error: ${error.message}`);
        return null;
    }
}

module.exports = {
    notifyIncidentOnSlack,
};

// Example of how to use it (for testing purposes - requires .env setup for Slack & Jira base URL for link):
// (async () => {
//     if (require.main === module) { // Only run if this script is executed directly
//         require("dotenv").config({ path: "../../.env" }); // Adjust path to .env

//         if (!process.env.SLACK_BOT_TOKEN || !process.env.DEFAULT_SLACK_CHANNEL_ID || !process.env.JIRA_BASE_URL) {
//             console.warn("Please ensure SLACK_BOT_TOKEN, DEFAULT_SLACK_CHANNEL_ID, and JIRA_BASE_URL are set in .env for testing communicationManager.");
//             return;
//         }

//         const sampleAnomalies = [
//             {
//                 type: "HighResponseTime",
//                 service: "WebApp-Prod-Test",
//                 metric: "responseTimeMs",
//                 value: 600,
//                 threshold: 450,
//                 message: "High response time detected for WebApp-Prod-Test: 600.00ms (Threshold: 450ms)",
//             }
//         ];
//         const sampleJiraResult = { key: "TEST-123", self: "https://your-domain.atlassian.net/rest/api/3/issue/TEST-123" };

//         await notifyIncidentOnSlack(sampleAnomalies, sampleJiraResult);
        
//         const sampleAnomaliesNoJira = [
//             {
//                 type: "HighErrorRate",
//                 service: "API-Gateway-Test",
//                 metric: "errorRatePercent",
//                 value: 10,
//                 threshold: 5,
//                 message: "High error rate for API-Gateway-Test: 10% (Threshold: 5%)",
//             }
//         ];
//         await notifyIncidentOnSlack(sampleAnomaliesNoJira, null);
//     }
// })();

