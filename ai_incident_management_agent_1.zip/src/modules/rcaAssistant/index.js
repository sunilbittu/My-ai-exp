// src/modules/rcaAssistant/index.js
const { generateText } = require("../../services/gptService");

/**
 * Generates potential root cause analysis (RCA) suggestions and troubleshooting steps
 * for a given set of anomalies using an AI model (via gptService).
 *
 * @param {Array<object>} anomalies - An array of anomaly objects detected by the incidentDetector.
 * Each anomaly object should have at least `service`, `type`, `metric`, `value`, `threshold`, and `message`.
 * @returns {Promise<string|null>} A string containing AI-generated RCA suggestions, or null if an error occurs or no anomalies.
 */
async function getAI_RCASuggestions(anomalies) {
    if (!anomalies || anomalies.length === 0) {
        console.log("RCAAssistant: No anomalies provided, skipping AI RCA suggestions.");
        return null;
    }

    // Construct a detailed prompt for the AI
    const serviceName = anomalies[0].service; // Assuming all anomalies are for the same service in this batch
    let prompt = `An incident has occurred with the following anomalies detected for service "${serviceName}":\n\n`;

    anomalies.forEach((anomaly, index) => {
        prompt += `Anomaly ${index + 1}:\n`;
        prompt += `  - Type: ${anomaly.type}\n`;
        prompt += `  - Metric: ${anomaly.metric}\n`;
        prompt += `  - Detected Value: ${anomaly.value}\n`;
        prompt += `  - Threshold: ${anomaly.threshold}\n`;
        prompt += `  - Message: ${anomaly.message}\n\n`;
    });

    prompt += "Based on these anomalies, please provide the following in a clear, concise format suitable for an incident ticket:\n";
    prompt += "1. Two to three potential common root causes for these types of issues.\n";
    prompt += "2. Two to three initial troubleshooting steps an engineer should perform to investigate further.\n";
    prompt += "Be specific and actionable.";

    try {
        console.log(`RCAAssistant: Generating AI RCA suggestions for ${serviceName}...`);
        // Assuming gptService.generateText takes prompt, model (optional), max_tokens (optional)
        // We use the default model configured in gptService (likely DeepSeek)
        const rcaSuggestions = await generateText(prompt, undefined, 300); // Max 300 tokens for suggestions
        
        if (rcaSuggestions) {
            console.log(`RCAAssistant: AI RCA suggestions generated for ${serviceName}.`);
            return `\n\n--- AI-Powered RCA Suggestions ---\n${rcaSuggestions.trim()}`;
        }
        console.warn("RCAAssistant: AI did not return any suggestions.");
        return null;
    } catch (error) {
        console.error(`RCAAssistant: Error generating AI RCA suggestions for ${serviceName}: ${error.message}`);
        return null; // Return null so the rest of the process can continue
    }
}

module.exports = {
    getAI_RCASuggestions,
};

// Example of how to use it (for testing purposes - requires .env setup for DeepSeek API key):
// (async () => {
//     if (require.main === module) { // Only run if this script is executed directly
//         require("dotenv").config({ path: "../../.env" }); // Adjust path to .env

//         if (!process.env.DEEPSEEK_API_KEY) {
//             console.warn("Please ensure DEEPSEEK_API_KEY is set in .env for testing rcaAssistant.");
//             return;
//         }

//         const sampleAnomalies = [
//             {
//                 type: "HighResponseTime",
//                 service: "ECommerce-Checkout-Service",
//                 metric: "responseTimeMs",
//                 value: 1250,
//                 threshold: 800,
//                 message: "High response time detected for ECommerce-Checkout-Service: 1250.00ms (Threshold: 800ms)",
//             },
//             {
//                 type: "HighErrorRate",
//                 service: "ECommerce-Checkout-Service",
//                 metric: "errorRatePercent",
//                 value: 7.5,
//                 threshold: 3,
//                 message: "High error rate detected for ECommerce-Checkout-Service: 7.50% (Threshold: 3%)",
//             }
//         ];

//         const suggestions = await getAI_RCASuggestions(sampleAnomalies);
//         if (suggestions) {
//             console.log("\nReceived AI RCA Suggestions:");
//             console.log(suggestions);
//         }
//     }
// })();

