// src/modules/incidentDetector/anomalyDetection.js
const { executeNRQL } = require("../../services/newrelicService");

/**
 * Fetches key performance metrics for a given application from New Relic.
 * @param {string} appName - The name of the application in New Relic.
 * @returns {Promise<object>} A promise that resolves to an object containing metrics like responseTimeMs, errorRatePercent.
 * @throws {Error} If the NRQL query fails or data parsing is unsuccessful.
 */
async function getNewRelicMetrics(appName) {
    console.log(`Fetching New Relic metrics for application: ${appName}...`);

    // Ensure appName is properly escaped for NRQL if it can contain special characters.
    // For simplicity here, we assume appName is safe. In production, consider sanitization/escaping.
    const nrqlQuery = `SELECT average(duration) * 1000 AS responseTimeMs, percentage(count(*), WHERE error IS TRUE) AS errorRatePercent FROM Transaction WHERE appName = '${appName}' SINCE 5 minutes ago`;

    try {
        // The API key is handled by newrelicService.js using environment variables
        const nrqlResults = await executeNRQL(nrqlQuery);

        if (nrqlResults && nrqlResults.results && nrqlResults.results.length > 0) {
            const metrics = nrqlResults.results[0];
            // Ensure the results have the expected properties, provide defaults if not
            const responseTimeMs = metrics.responseTimeMs !== null && metrics.responseTimeMs !== undefined ? parseFloat(metrics.responseTimeMs) : 0;
            const errorRatePercent = metrics.errorRatePercent !== null && metrics.errorRatePercent !== undefined ? parseFloat(metrics.errorRatePercent) : 0;
            
            console.log(`Metrics for ${appName}: ResponseTime=${responseTimeMs.toFixed(2)}ms, ErrorRate=${errorRatePercent.toFixed(2)}%`);
            return {
                responseTimeMs: responseTimeMs,
                errorRatePercent: errorRatePercent,
            };
        } else {
            console.warn(`No metrics data returned from New Relic for app: ${appName}. Query: ${nrqlQuery}. Results: ${JSON.stringify(nrqlResults)}`);
            // Return default/zero values if no data, so anomaly checker doesn't break
            return {
                responseTimeMs: 0,
                errorRatePercent: 0,
            };
        }
    } catch (error) {
        console.error(`Error fetching New Relic metrics for ${appName}:`, error.message);
        // Propagate the error or return default values to prevent cascading failures
        // For now, returning defaults to allow anomaly checker to proceed, but this could be an alert itself.
        return {
            responseTimeMs: 0,
            errorRatePercent: 0,
        };
    }
}


/**
 * Checks for anomalies in the provided metrics based on predefined thresholds.
 * @param {string} serviceName - The name of the service being checked (corresponds to appName in New Relic).
 * @param {object} metrics - An object containing metrics like responseTimeMs, errorRatePercent.
 * @returns {Array<object>} An array of detected anomaly objects, or an empty array if no anomalies.
 */
function checkForAnomalies(serviceName, metrics) {
    const anomalies = [];
    // Thresholds might need to be more dynamic or configurable in a real system
    const thresholds = {
        // Example: appName in New Relic could be 'MyWebApp-Production'
        "Your Application Name": { // Replace with actual application names you monitor
            responseTimeMs: 450,
            errorRatePercent: 4,
        },
        "Another Microservice": {
            responseTimeMs: 100,
            errorRatePercent: 1.5,
        },
        default: { // Default thresholds if specific service isn't listed
            responseTimeMs: 300,
            errorRatePercent: 3,
        }
    };

    const serviceThresholds = thresholds[serviceName] || thresholds.default;

    if (metrics.responseTimeMs > serviceThresholds.responseTimeMs) {
        anomalies.push({
            type: "HighResponseTime",
            service: serviceName,
            metric: "responseTimeMs",
            value: metrics.responseTimeMs,
            threshold: serviceThresholds.responseTimeMs,
            message: `High response time detected for ${serviceName}: ${metrics.responseTimeMs.toFixed(2)}ms (Threshold: ${serviceThresholds.responseTimeMs}ms)`,
        });
    }

    if (metrics.errorRatePercent > serviceThresholds.errorRatePercent) {
        anomalies.push({
            type: "HighErrorRate",
            service: serviceName,
            metric: "errorRatePercent",
            value: metrics.errorRatePercent,
            threshold: serviceThresholds.errorRatePercent,
            message: `High error rate detected for ${serviceName}: ${metrics.errorRatePercent.toFixed(2)}% (Threshold: ${serviceThresholds.errorRatePercent}%)`,
        });
    }

    // Example for customMetric - this would require a different NRQL query in getNewRelicMetrics
    // if (metrics.customMetric && serviceThresholds.customMetric && metrics.customMetric > serviceThresholds.customMetric) {
    //     anomalies.push({
    //         type: "HighCustomMetric",
    //         service: serviceName,
    //         metric: "customMetric",
    //         value: metrics.customMetric,
    //         threshold: serviceThresholds.customMetric,
    //         message: `High custom metric detected for ${serviceName}: ${metrics.customMetric.toFixed(2)} (Threshold: ${serviceThresholds.customMetric})`,
    //     });
    // }

    return anomalies;
}

module.exports = {
    getNewRelicMetrics, // Exporting the new function
    checkForAnomalies,
};

