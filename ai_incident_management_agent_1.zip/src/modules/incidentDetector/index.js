// src/modules/incidentDetector/index.js
const { getNewRelicMetrics, checkForAnomalies } = require("./anomalyDetection");
const { createIncidentTicketFromAnomalies } = require("../ticketManager/index");
const { notifyIncidentOnSlack } = require("../communicationManager/index");
const { getAI_RCASuggestions } = require("../rcaAssistant/index"); // Import the rcaAssistant function

/**
 * Main function to detect incidents for a given New Relic application name.
 * It fetches metrics, checks for anomalies, generates AI RCA suggestions, creates a Jira ticket, and sends a Slack notification.
 * @param {string} appName - The name of the application in New Relic to monitor.
 * @returns {Promise<Array<object>>} A promise that resolves to an array of detected anomaly objects.
 */
async function detectIncidents(appName) {
    console.log(`Starting incident detection for New Relic application: ${appName}`);
    let ticketResult = null; 
    let aiRcaSuggestions = null;

    try {
        const metrics = await getNewRelicMetrics(appName);
        console.log(`Metrics received for ${appName} from New Relic:`, metrics);

        const detectedAnomalies = checkForAnomalies(appName, metrics);

        if (detectedAnomalies.length > 0) {
            console.log(`
!!! ANOMALIES DETECTED for ${appName} !!!`);
            for (const anomaly of detectedAnomalies) {
                console.log(`- ${anomaly.message}`);
            }
            console.log("-----------------------------------------------------");

            // Attempt to get AI RCA Suggestions
            try {
                console.log(`Attempting to generate AI RCA suggestions for ${appName}...`);
                aiRcaSuggestions = await getAI_RCASuggestions(detectedAnomalies);
                if (aiRcaSuggestions) {
                    console.log("AI RCA suggestions generated.");
                } else {
                    console.warn("AI RCA suggestions were not generated or an error occurred.");
                }
            } catch (rcaError) {
                console.error(`Error during AI RCA suggestion generation for ${appName}: ${rcaError.message}`);
                // aiRcaSuggestions remains null
            }

            // Attempt to create a Jira ticket, now including AI suggestions
            try {
                console.log(`Attempting to create Jira ticket for anomalies in ${appName}...`);
                // Pass aiRcaSuggestions to the ticket manager
                ticketResult = await createIncidentTicketFromAnomalies(detectedAnomalies, aiRcaSuggestions);
                if (ticketResult) {
                    console.log(`Jira ticket creation successful: ${ticketResult.key}`);
                } else {
                    console.warn(`Jira ticket creation was not successful or was skipped for ${appName}.`);
                }
            } catch (e) {
                console.error(`Error during Jira ticket creation for ${appName}: ${e.message}`);
                // ticketResult remains null
            }

            // Attempt to send a Slack notification
            try {
                console.log(`Attempting to send Slack notification for ${appName}...`);
                // Slack notification can also be enhanced to mention AI RCA if needed, 
                // but for now, it primarily uses ticketResult.
                await notifyIncidentOnSlack(detectedAnomalies, ticketResult);
            } catch (slackError) {
                console.error(`Error during Slack notification for ${appName}: ${slackError.message}`);
            }

            return detectedAnomalies;
        } else {
            console.log(`No anomalies detected for ${appName}. System normal based on current thresholds.`);
            return [];
        }
    } catch (error) {
        console.error(`Error during incident detection for ${appName}:`, error.message);
        return []; 
    }
}

module.exports = {
    detectIncidents,
};

// Example usage (for testing this module directly - requires .env setup for New Relic, Jira, Slack & DeepSeek):
// (async () => {
//     if (require.main === module) { 
//         require("dotenv").config({ path: "../../.env" }); 
//         const testAppName = process.env.TEST_NEW_RELIC_APP_NAME;
//         if (!testAppName || 
//             !process.env.NEW_RELIC_API_KEY || 
//             !process.env.JIRA_BASE_URL || 
//             !process.env.SLACK_BOT_TOKEN || 
//             !process.env.DEFAULT_SLACK_CHANNEL_ID ||
//             !process.env.DEEPSEEK_API_KEY) { // Ensure DeepSeek API key is checked
//             console.warn("Please ensure all required environment variables (New Relic, Jira, Slack, DeepSeek) are set in your .env file for a full test.");
//             return;
//         }
//         console.log(`Running full incident detection, AI RCA, ticketing, and notification test for app: ${testAppName}`);
//         await detectIncidents(testAppName);
//     }
// })();

