const { WebClient } = require("@slack/web-api");

// Environment variable to be set in .env file:
// SLACK_BOT_TOKEN=xoxb-your-slack-bot-token

const SLACK_BOT_TOKEN = process.env.SLACK_BOT_TOKEN;
let slackClient;

if (SLACK_BOT_TOKEN) {
    slackClient = new WebClient(SLACK_BOT_TOKEN);
} else {
    console.warn("Slack Bot Token (SLACK_BOT_TOKEN) is not set. Slack notifications will be disabled.");
}

/**
 * Sends a message to a specified Slack channel ID.
 * @param {string} channelId - The ID of the Slack channel (e.g., "C0123456789").
 * @param {string} text - The plain text fallback message.
 * @param {Array<object>} [blocks] - (Optional) Slack Block Kit blocks for rich message formatting.
 * @returns {Promise<object|null>} The response data from Slack API upon successful message post, or null if disabled/error.
 * @throws {Error} If the API call fails and slackClient is initialized.
 */
async function sendMessageToChannel(channelId, text, blocks = undefined) {
    if (!slackClient) {
        console.warn("Slack client not initialized. Cannot send message. Ensure SLACK_BOT_TOKEN is set.");
        return null;
    }

    if (!channelId || !text) {
        throw new Error("Missing required parameters: channelId and text must be provided.");
    }

    try {
        const result = await slackClient.chat.postMessage({
            channel: channelId,
            text: text, // Fallback text for notifications
            blocks: blocks, // Optional Block Kit for richer messages
        });
        console.log(`Message sent successfully to channel ${channelId}. TS: ${result.ts}`);
        return result;
    } catch (error) {
        console.error(`Error sending message to Slack channel ${channelId}:`, error.message);
        // Log more details if available, e.g., error.data from Slack API
        if (error.data) {
            console.error("Slack API Error Data:", error.data);
        }
        throw error; // Re-throw for the caller to handle
    }
}

module.exports = {
    sendMessageToChannel,
};

// Example of how to use it (for testing purposes - requires .env setup for Slack):
// (async () => {
//     if (require.main === module) { // Only run if this script is executed directly
//         require("dotenv").config(); // Load .env file

//         const testChannelId = process.env.TEST_SLACK_CHANNEL_ID; // Set in .env, e.g., "C0123456789"

//         if (!SLACK_BOT_TOKEN || !testChannelId) {
//             console.warn("Please set SLACK_BOT_TOKEN and TEST_SLACK_CHANNEL_ID in your .env file for testing slackService.");
//             return;
//         }

//         const simpleTextMessage = "Hello from the AI Incident Management Agent! This is a test message.";
//         const blockKitMessage = [
//             {
//                 "type": "section",
//                 "text": {
//                     "type": "mrkdwn",
//                     "text": "*AI Incident Agent Test Notification* :robot_face:"
//                 }
//             },
//             {
//                 "type": "divider"
//             },
//             {
//                 "type": "section",
//                 "fields": [
//                     {
//                         "type": "mrkdwn",
//                         "text": "*Service:*\nMy Web App"
//                     },
//                     {
//                         "type": "mrkdwn",
//                         "text": "*Status:*\n:red_circle: Anomaly Detected"
//                     }
//                 ]
//             },
//             {
//                 "type": "section",
//                 "text": {
//                     "type": "mrkdwn",
//                     "text": "Details: High error rate observed. <fakelink.to.jira.ticket|JIRA-123>"
//                 }
//             }
//         ];

//         try {
//             console.log(`Attempting to send a simple text message to channel: ${testChannelId}`);
//             await sendMessageToChannel(testChannelId, simpleTextMessage);

//             console.log(`\nAttempting to send a Block Kit message to channel: ${testChannelId}`);
//             await sendMessageToChannel(testChannelId, "Fallback text for Block Kit message", blockKitMessage);

//         } catch (error) {
//             console.error("Failed to send sample Slack message(s):", error.message);
//         }
//     }
// })();

