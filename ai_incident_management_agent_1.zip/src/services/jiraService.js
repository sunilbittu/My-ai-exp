const fetch = require("node-fetch");
const Buffer = require("buffer").Buffer; // For Base64 encoding

// Environment variables to be set in .env file:
// JIRA_BASE_URL=https://your-domain.atlassian.net (e.g., https://mycompany.atlassian.net)
// JIRA_EMAIL=your_jira_email@example.com
// JIRA_PAT=your_jira_personal_access_token

const JIRA_BASE_URL = process.env.JIRA_BASE_URL;
const JIRA_EMAIL = process.env.JIRA_EMAIL;
const JIRA_PAT = process.env.JIRA_PAT;

/**
 * Creates a Jira ticket using the Jira Cloud REST API.
 * @param {object} ticketDetails - Details for the ticket.
 * @param {string} ticketDetails.projectKey - The key of the Jira project (e.g., "PROJ").
 * @param {string} ticketDetails.summary - The summary/title of the ticket.
 * @param {string} ticketDetails.description - The detailed description for the ticket (can be rich text/ADF).
 * @param {string} ticketDetails.issueTypeName - The name of the issue type (e.g., "Bug", "Task", "Incident").
 * @param {string} [ticketDetails.priorityName] - (Optional) The name of the priority (e.g., "High", "Medium").
 * @param {Array<string>} [ticketDetails.labels] - (Optional) An array of labels for the ticket.
 * @returns {Promise<object>} The response data from Jira API upon successful creation.
 * @throws {Error} If the API call fails or required environment variables are not set.
 */
async function createJiraTicket(ticketDetails) {
    if (!JIRA_BASE_URL || !JIRA_EMAIL || !JIRA_PAT) {
        throw new Error("Jira configuration (JIRA_BASE_URL, JIRA_EMAIL, JIRA_PAT) is not set in environment variables.");
    }

    const { projectKey, summary, description, issueTypeName, priorityName, labels } = ticketDetails;

    if (!projectKey || !summary || !description || !issueTypeName) {
        throw new Error("Missing required ticket details: projectKey, summary, description, issueTypeName.");
    }

    const jiraApiEndpoint = `${JIRA_BASE_URL}/rest/api/3/issue`;

    const authHeader = `Basic ${Buffer.from(`${JIRA_EMAIL}:${JIRA_PAT}`).toString("base64")}`;

    const payload = {
        fields: {
            project: {
                key: projectKey,
            },
            summary: summary,
            description: {
                type: "doc",
                version: 1,
                content: [
                    {
                        type: "paragraph",
                        content: [
                            {
                                type: "text",
                                text: description,
                            },
                        ],
                    },
                ],
            }, // Atlassian Document Format (ADF)
            issuetype: {
                name: issueTypeName,
            },
        },
    };

    if (priorityName) {
        payload.fields.priority = { name: priorityName };
    }

    if (labels && labels.length > 0) {
        payload.fields.labels = labels;
    }

    try {
        const response = await fetch(jiraApiEndpoint, {
            method: "POST",
            headers: {
                "Authorization": authHeader,
                "Accept": "application/json",
                "Content-Type": "application/json",
            },
            body: JSON.stringify(payload),
        });

        const responseData = await response.json();

        if (!response.ok) {
            console.error("Jira API Error Response:", responseData);
            const errorMessage = responseData.errorMessages ? responseData.errorMessages.join("; ") : `Jira API request failed with status ${response.status}`;
            throw new Error(errorMessage);
        }

        console.log(`Jira ticket created successfully: ${responseData.key} - ${responseData.self}`);
        return responseData; // Contains id, key, self (link to the issue)

    } catch (error) {
        console.error("Error creating Jira ticket:", error.message);
        throw error; // Re-throw for the caller to handle
    }
}

module.exports = {
    createJiraTicket,
};

// Example of how to use it (for testing purposes):
// (async () => {
//     if (require.main === module) { // Only run if this script is executed directly
//         require("dotenv").config(); // Load .env file

//         const sampleTicket = {
//             projectKey: "YOUR_PROJECT_KEY", // Replace with your project key
//             summary: "Automated Test Incident - High Error Rate",
//             description: "This is an automated incident ticket created by the AI Management Agent. Error rate exceeded threshold.",
//             issueTypeName: "Bug", // Or "Incident", "Task" depending on your Jira setup
//             priorityName: "High",
//             labels: ["auto-generated", "incident", "ai-agent"]
//         };

//         if (sampleTicket.projectKey === "YOUR_PROJECT_KEY" || !process.env.JIRA_BASE_URL) {
//             console.warn("Please set JIRA_BASE_URL, JIRA_EMAIL, JIRA_PAT in your .env file and update sampleTicket.projectKey for testing.");
//             return;
//         }

//         try {
//             console.log(`Attempting to create Jira ticket: ${sampleTicket.summary}`);
//             const result = await createJiraTicket(sampleTicket);
//             console.log("Jira Ticket Creation Result:", JSON.stringify(result, null, 2));
//         } catch (error) {
//             console.error("Failed to create sample Jira ticket:", error.message);
//         }
//     }
// })();

