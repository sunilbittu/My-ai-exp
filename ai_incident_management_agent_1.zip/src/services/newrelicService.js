const fetch = require("node-fetch");

// It's highly recommended to use environment variables for API keys and account IDs.
// For example, in your .env file:
// NEW_RELIC_API_KEY=your_api_key_here
// NEW_RELIC_ACCOUNT_ID=your_account_id_here (optional, but good for some queries)

const NEW_RELIC_API_KEY = process.env.NEW_RELIC_API_KEY;
const NERDGRAPH_API_URL = process.env.NEW_RELIC_NERDGRAPH_URL || "https://api.newrelic.com/graphql"; // Default to US endpoint

/**
 * Executes an NRQL query against the New Relic NerdGraph API.
 * @param {string} nrqlQuery - The NRQL query string.
 * @param {string} apiKey - (Optional) The New Relic User API Key. Defaults to process.env.NEW_RELIC_API_KEY.
 * @returns {Promise<object>} The data part of the GraphQL response.
 * @throws {Error} If the API call fails or returns errors.
 */
async function executeNRQL(nrqlQuery, apiKey = NEW_RELIC_API_KEY) {
    if (!apiKey) {
        throw new Error("New Relic API Key is not provided or set in environment variables (NEW_RELIC_API_KEY).");
    }

    const graphqlQuery = {
        query: `{
            actor {
                account(id: ${process.env.NEW_RELIC_ACCOUNT_ID || 'YOUR_ACCOUNT_ID'}) { # Replace YOUR_ACCOUNT_ID or set NEW_RELIC_ACCOUNT_ID in .env
                    nrql(query: "${nrqlQuery}") {
                        results
                        metadata {
                            eventTypes
                            facets
                        }
                        totalResult
                    }
                }
            }
        }`,
    };

    try {
        const response = await fetch(NERDGRAPH_API_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "API-Key": apiKey,
            },
            body: JSON.stringify(graphqlQuery),
        });

        if (!response.ok) {
            const errorBody = await response.text();
            throw new Error(`NerdGraph API request failed with status ${response.status}: ${errorBody}`);
        }

        const responseJson = await response.json();

        if (responseJson.errors && responseJson.errors.length > 0) {
            console.error("NerdGraph API returned errors:", JSON.stringify(responseJson.errors, null, 2));
            throw new Error(`NerdGraph API error: ${responseJson.errors.map(e => e.message).join("; ")}`);
        }

        // Extract the relevant part of the data
        if (responseJson.data && responseJson.data.actor && responseJson.data.actor.account && responseJson.data.actor.account.nrql) {
            return responseJson.data.actor.account.nrql;
        }
        
        console.warn("Unexpected response structure from NerdGraph API:", responseJson);
        throw new Error("Unexpected response structure from NerdGraph API.");

    } catch (error) {
        console.error("Error executing NRQL query via NerdGraph:", error.message);
        throw error; // Re-throw for the caller to handle
    }
}

module.exports = {
    executeNRQL,
};

// Example of how to use it (for testing purposes):
// (async () => {
//     if (require.main === module) { // Only run if this script is executed directly
//         require('dotenv').config(); // Load .env file for NEW_RELIC_API_KEY and NEW_RELIC_ACCOUNT_ID
//         const sampleQuery = "SELECT average(duration) FROM Transaction WHERE appName = 'Your Application Name' SINCE 1 hour ago";
//         try {
//             console.log(`Executing NRQL: ${sampleQuery}`);
//             const results = await executeNRQL(sampleQuery);
//             console.log("NRQL Results:", JSON.stringify(results, null, 2));
//         } catch (error) {
//             console.error("Failed to execute sample NRQL query:", error.message);
//         }
//     }
// })();

