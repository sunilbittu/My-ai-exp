const axios = require('axios');

// It's highly recommended to use environment variables for API keys.
// You would typically load this using a library like dotenv.
// For example, in your .env file: DEEPSEEK_API_KEY=your_api_key_here
const DEEPSEEK_API_KEY = process.env.DEEPSEEK_API_KEY;
const DEEPSEEK_API_URL = 'https://api.deepseek.com/v1/chat/completions'; // Please verify the correct API endpoint

/**
 * Generates text using the DeepSeek API.
 * @param {string} prompt - The prompt to send to the DeepSeek API.
 * @param {string} model - The model to use (e.g., 'deepseek-chat').
 * @param {number} maxTokens - The maximum number of tokens to generate.
 * @returns {Promise<string>} The generated text.
 * @throws {Error} If the API call fails.
 */
async function generateText(prompt, model = 'deepseek-chat', maxTokens = 500) {
    if (!DEEPSEEK_API_KEY) {
        throw new Error('DEEPSEEK_API_KEY is not set. Please set it in your environment variables.');
    }

    try {
        const response = await axios.post(
            DEEPSEEK_API_URL,
            {
                model: model,
                messages: [
                    { role: 'user', content: prompt }
                ],
                max_tokens: maxTokens,
                // Add any other parameters required by the DeepSeek API
            },
            {
                headers: {
                    'Authorization': `Bearer ${DEEPSEEK_API_KEY}`,
                    'Content-Type': 'application/json',
                },
            }
        );

        if (response.data && response.data.choices && response.data.choices.length > 0) {
            // Adjust this based on the actual structure of the DeepSeek API response
            return response.data.choices[0].message.content.trim();
        } else {
            throw new Error('Invalid response structure from DeepSeek API');
        }
    } catch (error) {
        console.error('Error calling DeepSeek API:', error.response ? error.response.data : error.message);
        throw new Error('Failed to generate text using DeepSeek API.');
    }
}

module.exports = {
    generateText,
};

